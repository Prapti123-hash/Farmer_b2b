from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from shop.models.customer import Customer
from django.views import View


class Signup (View):
    def get(self, request):
        return render (request, 'signup.html')

    def post(self, request):
        postData = request.POST
        name=postData.get('name')
        adhar_number = postData.get ('adhar_number')
        location= postData.get ('location')
        category=postData.get('category')
        password = postData.get ('password')
        confirm_password=postData.get('confirm_password')
        # validation
        value = {
            'adhar_number': adhar_number,
            'location': location,
            'category': category,
            'name':name,
        }
        error_message = None

        buyer = Buyer (adhar_number=adhar_number,
                             name=name,
                             password=password,
                             confirm_password=confirm_password,
                             location=location,
                             category=category)
        error_message = self.validateBuyer (buyer)

        if not error_message:
            print (name,adhar_number, password, location, category)
            buyer.password = make_password (buyer.password)
            buyer.register ()
            return redirect ('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render (request, 'signup.html', data)

    def validateBuyer(self, customer):
        error_message = None
        if (not buyer.name):
            error_message = "Please Enter your  Name !!"
        elif len (buyer.name) < 3:
            error_message = ' Name must be 3 char long or more'
        elif not buyer.adhar_number:
            error_message = 'Please Enter your adhar number'
        elif len (buyer.adhar_number) < 12:
            error_message = 'Aahar number must be 3 character long'
        elif not buyer.location:
            error_message = 'Enter your location'
        elif not buyer.category:
            error_message = 'Enter Location'
        elif len (buyer.password) < 5:
            error_message = 'Password must be 5 char long'
        
        elif customer.isExists ():
            error_message = 'Adhar number  Already Registered..'
        # saving


        return error_message
