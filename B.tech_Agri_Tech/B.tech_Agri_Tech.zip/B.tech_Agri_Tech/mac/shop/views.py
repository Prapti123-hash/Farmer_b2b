from django.shortcuts import render
from django.http import HttpResponse
"""def index(request):
    return render(request,'shop/index.html')
def about(request):
    return HttpResponse("We are at about")

def contact(request):
    return render(request,'shop/contact.html')

def tracker(request):
    return HttpResponse("We are at tracking")

def search(request):
    return HttpResponse("We are at search")

def productView(request):
    return render(request,'shop/Product.html')
def checkout(request):
    return HttpResponse("We are at checkout")
def login(request):
    return render(request,'shop/login.html')
def signup(request):
    return render(request,'shop/signup.html')"""