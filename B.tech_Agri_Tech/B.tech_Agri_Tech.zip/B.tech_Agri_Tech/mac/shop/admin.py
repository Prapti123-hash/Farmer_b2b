from django.contrib import admin

# Register your models here.
from .models import Product
from .models import Buyer
from .models import Farmer
from .models import Category
from .models import Payment
from .models import MonetaryHelp
admin.site.register(Product)
admin.site.register(Buyer)
admin.site.register(Farmer)
admin.site.register(MonetaryHelp)
admin.site.register(Payment)
admin.site.register(Category)